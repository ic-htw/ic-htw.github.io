package de.htwberlin.utils;

public interface DbCred {
	  final String driverClass = "oracle.jdbc.driver.OracleDriver";
	  final String url = "jdbc:oracle:thin:@xxx";
	  final String user = "uxxx";
	  final String password = "pxxx";
	  final String schema = "uxxx";
}
