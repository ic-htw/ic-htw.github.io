package de.htwberlin.utils;

public interface DbCred {

  final String driverClass = "oracle.jdbc.driver.OracleDriver";
  final String url = "jdbc:oracle:thin:@host.f4.htw-berlin.de:1521:oradb1";
  final String user = "userid";
  final String password = "password";
  final String schema = "schema";
}