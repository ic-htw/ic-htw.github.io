create table Raum (
  RID integer not null primary key,
  RaumNr varchar2(10) not null,
  AnzahlSitze integer
);
