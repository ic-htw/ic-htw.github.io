insert into Raum (RID, RaumNr, AnzahlSitze) values (1, 'A027', 60);
insert into Raum (RID, RaumNr, AnzahlSitze) values (2, 'A028', 30);
insert into Raum (RID, RaumNr, AnzahlSitze) values (3, 'A029', 40);
