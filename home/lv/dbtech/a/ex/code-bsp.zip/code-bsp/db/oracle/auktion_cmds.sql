--select table_name from user_tables;
select * from Angebot order by AID;
select * from Gebot order by GID;

delete from Gebot where GID=15002;