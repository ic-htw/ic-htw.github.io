--select table_name FROM user_tables;

--insert into Raum (RID, RaumNr, AnzahlSitze) values (99, 'A099', 27);
select * from raum;


