delete from Gebot;
delete from Angebot;
