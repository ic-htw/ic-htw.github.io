package de.htwberlin.utils;

public interface DbCred {
  final String driverClass = "oracle.jdbc.driver.OracleDriver";
  final String url = "jdbc:oracle:thin:@aaa:1521:orcl";
  final String user = "uuu";
  final String password = "ppp";
  final String schema = "uuu";
}
